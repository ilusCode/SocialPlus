/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebaconexionbd;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;




/**
 *
 * @author Black Dragon
 */
public class PruebaConexionBD
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Connection conexion;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/tienda3", "root", "123456");
            Statement s = (Statement) conexion.createStatement();
           // int result = s.executeUpdate("Insert into producto values(default,default,default,default,7)");
            String nombre = "M&M",estante = "A", fecha = "2018-05-01";
            int clave = 9;
            float precio= 20.5f;
            String cadena = "INSERT INTO PRODUCTO VALUES('"+nombre+"',"+precio+",'"+estante+"','"+fecha+"',"+clave+")";
            
            int resultado = s.executeUpdate(cadena);
            
            System.out.println("Inserte: "+resultado+" elementos");
        } catch (ClassNotFoundException ex)
        {
            System.out.println("Error con el driver");
            Logger.getLogger(PruebaConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex)
        {
            System.out.println("Error al conectar a la BD");
            Logger.getLogger(PruebaConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
