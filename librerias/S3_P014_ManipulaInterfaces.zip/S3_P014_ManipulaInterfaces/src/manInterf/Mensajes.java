/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manInterf;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Black Dragon
 */
public class Mensajes
{

    public static void exito(String s, JFrame jf)
    {
        JOptionPane.showMessageDialog(jf, s, "Transacción correcta", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(String s, JFrame jf)
    {
        JOptionPane.showMessageDialog(jf, s, "Transacción incorrecta", JOptionPane.ERROR_MESSAGE);
    }

    public static int pregunta(String s, JFrame jf)
    {
        return JOptionPane.showConfirmDialog(jf, s, "Confirmar Transacción", JOptionPane.YES_NO_OPTION);
    }

}
