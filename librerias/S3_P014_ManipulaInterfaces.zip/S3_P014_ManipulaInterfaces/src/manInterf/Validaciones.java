/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manInterf;

import com.toedter.calendar.JDateChooser;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Black Dragon
 */
public class Validaciones
{
    public static SimpleDateFormat Formato = new SimpleDateFormat("dd-MM-yyyy");    
    public static void entero(KeyEvent ke)
    {
        if ((ke.getKeyChar() < '0' || ke.getKeyChar() > '9') && (ke.getKeyCode() != 8))
        //Validación de entero
        {
            ke.setKeyChar((char) 8); //Backspace borrar
        }
    }

    private static final String PATTERN_ALFABETO = "[_A-Za-zÁ-Úá-ú' ''ñ''Ñ''.']*";

    public static boolean alfabeto(String email)
    {

        // Compiles the given regular expression into a pattern.
        Pattern pattern = Pattern.compile(PATTERN_ALFABETO);
        // Match the given input against this pattern
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();

    }
    private static final String PATTERN_NUM = "[_0-9]*";

    public static boolean numerico(String dir)
    {

        // Compiles the given regular expression into a pattern.
        Pattern pattern = Pattern.compile(PATTERN_NUM);
        // Match the given input against this pattern
        Matcher matcher = pattern.matcher(dir);
        return matcher.matches();

    }

    private static final String PATTERN_ALFANUM = "[_A-Za-zÁ-Úá-ú' '0-9'.''-']*";

    public static boolean alfanumerico(String dir)
    {

        // Compiles the given regular expression into a pattern.
        Pattern pattern = Pattern.compile(PATTERN_ALFANUM);
        // Match the given input against this pattern
        Matcher matcher = pattern.matcher(dir);
        return matcher.matches();

    }
    private static final String PATTERN_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    public static boolean email(String email)
    {

        // Compiles the given regular expression into a pattern.
        Pattern pattern = Pattern.compile(PATTERN_EMAIL);
        // Match the given input against this pattern
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();

    }

    public static boolean vacio(JTextField... jt)
    {
        //Recibe un arreglo de textfields, verifica en cada uno que no esté vacio
        //si alguno de ellos está vacio se regresa un false, indicando la existencia de un vacio.
        
        boolean r = true;
        for (int i = 0; i < jt.length; i++)
        {
            if (jt[i].getText().isEmpty())
            {
                return false;
            } else
            {
                r = true;
            }
        }
        return r;
    }
        public static boolean vacio(JTextArea... jt)
    {
        //Recibe un arreglo de textfields, verifica en cada uno que no esté vacio
        //si alguno de ellos está vacio se regresa un false, indicando la existencia de un vacio.
        
        boolean r = true;
        for (int i = 0; i < jt.length; i++)
        {
            if (jt[i].getText().isEmpty())
            {
                return false;
            } else
            {
                r = true;
            }
        }
        return r;
    }
    
        public static String getFecha(JDateChooser jd)
    {

        if (jd.getDate() != null)
        {
            return Formato.format(jd.getDate());
        } else
        {
            return null;
        }
    }
   
    public static Date StringADate(String fecha)
    {
        SimpleDateFormat formato_del_Texto = new SimpleDateFormat("dd-MM-yyyy");
        Date fechaE = null;
        try
        {
            fechaE = formato_del_Texto.parse(fecha);
            return fechaE;
        } catch (Exception ex)
        {
            //Mensajes.error("Fecha Incorrecta", this);
            return null;
        }

    }   
            
    public static Date validarFecha(JDateChooser jdc){
        return StringADate(getFecha(jdc));
    }
}
