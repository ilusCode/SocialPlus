/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manInterf;

import java.awt.event.KeyEvent;
import javax.swing.*;
import com.toedter.calendar.*;




/**
 *
 * @author Black Dragon
 */
public class ManiInterfaces
//Mejorar la calidad de las interfaces
{

    public static void limpia(JTextField... jts)
    {
        for (int i = 0; i < jts.length; i++)
        {
            jts[i].setText("");
        }
    }
      public static void limpia(JTextArea... jts)
    {
        for (int i = 0; i < jts.length; i++)
        {
            jts[i].setText("");
        }
    }

    public static void habilita(boolean flag, Object... objs)

    {
        for (int i = 0; i < objs.length; i++)
        {
            if (objs[i] instanceof JCalendar)
            {
                ((JCalendar) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JDateChooser)
            {
                ((JDateChooser) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JButton)
            {
                ((JButton) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JTextField)
            {
                ((JTextField) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JTextArea)
            {
                ((JTextArea) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JComboBox)
            {
                ((JComboBox) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JMenuItem)
            {
                ((JMenuItem) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JMenu)
            {
                ((JMenu) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JCheckBoxMenuItem)
            {
                ((JButton) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JPasswordField)
            {
                ((JPasswordField) objs[i]).setEnabled(flag);
            }
            if (objs[i] instanceof JFormattedTextField)
            {
                ((JFormattedTextField) objs[i]).setEnabled(flag);
            }
        }
    }

    public static void cambia(Object obj)
    //Permite ir a otra caja de texto, otro componente...
    {
        habilita(true, obj);
        if (obj instanceof JButton)
        {

            ((JButton) obj).requestFocus();
        }
        if (obj instanceof JTextField)
        {
            ((JTextField) obj).setSelectionStart(0);
            ((JTextField) obj).requestFocus();
            ((JTextField) obj).setSelectionEnd(((JTextField) obj).getText().length());
        }
         if (obj instanceof JCalendar)
        {
            ((JCalendar) obj).requestFocus();
        }
           if (obj instanceof JDateChooser)
        {
            ((JDateChooser) obj).requestFocus();
        }
        if (obj instanceof JTextArea)
        {
            ((JTextArea) obj).requestFocus();
        }
        if (obj instanceof JComboBox)
        {
            ((JComboBox) obj).requestFocus();
        }
        if (obj instanceof JMenuItem)
        {
            ((JMenuItem) obj).requestFocus();
        }
        if (obj instanceof JMenu)
        {
            ((JMenu) obj).requestFocus();
        }
        if (obj instanceof JCheckBox)
        {
            ((JCheckBox) obj).requestFocus();
        }
        if (obj instanceof JCheckBoxMenuItem)
        {
            ((JCheckBoxMenuItem) obj).requestFocus();
        }
        if (obj instanceof JPasswordField)
        {
            ((JPasswordField) obj).requestFocus();
        }
        if (obj instanceof JFormattedTextField)
        {
            ((JFormattedTextField) obj).requestFocus();
        }
    }

    public static void val_enter_tab(Object obj, KeyEvent ke)
    {
        if (ke.getKeyChar() == '\n')
        {
            cambia(obj);
 
        }
    }
        public static boolean val_enter_tab_S(Object obj, KeyEvent ke)
    {
        if (ke.getKeyChar() == '\n')
        {
            return true;
 
        }
        return false;
    }
public static boolean val_enter_tab_Fechas(JDateChooser obj, KeyEvent ke)
    {
        if (ke.getKeyChar() == '\n')
        {
            return true;
 
        }
        return false;
    }

    public static void val_enter_entero(Object obj, KeyEvent ke, JFrame jf, JTextField jt)
    {
        if (ke.getKeyChar() == '\n')
        {
            Verifica.entero(jt, obj, jf);
        }
    }

    public static void val_enter_doble(Object obj, KeyEvent ke, JFrame jf, JTextField jt)
    {
        if (ke.getKeyChar() == '\n')
        {
            Verifica.doble(jt, obj, jf);
        }
    }
   

}
