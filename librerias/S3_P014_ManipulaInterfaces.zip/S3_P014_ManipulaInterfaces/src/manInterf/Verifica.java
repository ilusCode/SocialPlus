/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manInterf;

import javax.swing.JFrame;
import javax.swing.JTextField;

/**
 *
 * @author Black Dragon
 */
public class Verifica
{
    public static void entero(JTextField jt, Object obj, JFrame jf)
    {
        try{
            int x = Integer.parseInt(jt.getText());
            ManiInterfaces.cambia(obj);
        }catch(Exception e){
            Mensajes.error("Error se esperabá un entero", jf);
             
        }
    }
    
        public static void doble(JTextField jt, Object obj, JFrame jf)
    {
        try{
            double x = Double.parseDouble(jt.getText());
            ManiInterfaces.cambia(obj);
        }catch(Exception e){
            Mensajes.error("Error se esperabá un doble", jf);
             
        }
    }
            
}
